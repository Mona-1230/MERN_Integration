import { useState } from "react";

export default function AddProduct() {
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    description: '',
    image: ''
  });

  const handleInputChange = (e) => {
    setFormData({...formData, [e.target.name]: e.target.value});
  };

  const handleSubmit = async(e) => {
    e.preventDefault();
    const res = await fetch('http://localhost:5000/api/addproduct', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(formData)
    });
    if(res.ok){
      setFormData({name: '', price: '', description: '', image: ''});
      alert('Product added successfully');
    } else {
      alert('Failed to add product');
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <h2>Add New Product</h2>
        <input 
          name="name" 
          value={formData.name} 
          onChange={handleInputChange} 
          placeholder="Product Name" 
          required 
        />
        <input 
          name="price" 
          value={formData.price} 
          onChange={handleInputChange} 
          placeholder="Price" 
          type="number" 
          required 
        />
        <input 
          name="description" 
          value={formData.description} 
          onChange={handleInputChange} 
          placeholder="Description" 
          required 
        />
        <input 
          name="image" 
          value={formData.image} 
          onChange={handleInputChange} 
          placeholder="Image URL" 
          required 
        />
        <button type="submit">Add Product</button>
      </form>
    </div>
  );
}