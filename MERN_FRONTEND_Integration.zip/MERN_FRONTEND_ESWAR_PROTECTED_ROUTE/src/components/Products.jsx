import { useEffect, useState } from "react";
import { Link } from "react-router-dom";


export default function Products({setCart,cart}) {
  const[products,setProducts]=useState([])
  useEffect(()=>{
    fetch("http://localhost:5000/api/getproduct").then(res=>res.json()).then(data=>setProducts(data))
  })
 const addToCart = (item) => {
    setCart([...cart, item]);
  };
  return (
    <div>
        <h2>All Products</h2>
        {products.map(p => (
          <div key={p._id} >
            <img src={p.image} alt={p.name} width="150" />
            <h3>{p.name}</h3>
            <p>₹{p.price}</p>
             <Link to={`/product/${p._id}`}>View</Link> 
           <button onClick={() => addToCart(p)}>Add to Cart</button>
          </div>
        ))}
    </div>
  )
}