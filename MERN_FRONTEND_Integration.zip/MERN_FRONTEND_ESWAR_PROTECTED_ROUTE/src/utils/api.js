export const products = [
  {
    _id: "1",
    name: "Laptop",
    price: 55000,
    image: "https://picsum.photos/200",
    description: "High performance laptop"
  },
  {
    _id: "2",
    name: "Mobile",
    price: 25000,
    image: "https://picsum.photos/200",
    description: "Latest smartphone"
  },
  {
    _id: "3",
    name: "Headphones",
    price: 3000,
    image: "https://picsum.photos/200",
    description: "Noise cancelling headphones"
  }
];
